/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.jsu.mcis.lab5c;

public class Circle extends Shape {
   // instance fields/data fields
   private double radius;

   // parameterized constructor
   public Circle(int x, int y, int z, double r) {
       super(x, y, z);
       this.radius = r;
   }

   // getter method
   public double getRadius() {
       return this.radius; // return radius
   }

   // method to get area
   @Override
   public double area() {
       // return area of circle
       return Math.PI * this.radius * this.radius;
   }

   // method toString
   public String toString() {
       return "(" + getX() + ", " + getY() + ", " + getZ() + ")" + ":" + "(" +
               this.area() + ")";
   }
}