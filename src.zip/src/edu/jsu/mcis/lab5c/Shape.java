package edu.jsu.mcis.lab5c;

public abstract class Shape {
    private Point center;
    
    //constructors
    public Shape(int x, int y, int z) {
       this.center = new Point(x, y, z);
   }
   //all getters
   public int getX() {
       return center.getX();
   }

   public int getY() {
       return center.getY();
   }
  
   public int getZ() {
       return center.getZ();
   }
 
    public abstract double area();
}

