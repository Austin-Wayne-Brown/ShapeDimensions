package edu.jsu.mcis.lab5c;

public class Rectangle extends Shape {
   // instance fields
   private double length;
   private double width;

   // constructor
   public Rectangle(int x, int y, int z, double l, double w) {
       super(x, y, z);
       this.length = l;// set length
       this.width = w;// set width
   }

   // getter methods
   public double getLength() {
       return this.length;// return length
   }

   public double getWidth() {
       return this.width;// return width
   }

   // method to get area
   @Override
   public double area() { // return area of rectangle
       return this.length * this.width;
   }

   // method to string
   public String toString() {
       return "(" + getX() + ", " + getY() + ", " + getZ() + ")" + ":" + "[" + 
               this.area() + "]";
   }
}