package edu.jsu.mcis.lab5c;

public class Triangle extends Shape {
    
   // instance fields
   private double base; 
   private double height;

   //constructor
   public Triangle(int x, int y, int z, double b, double h) {
       super(x, y, z);
       this.base = b;// set base
       this.height = h;// set height
   }

   // getter methods
   public double getBase() {
       return this.base;// return base
   }

   public double getHeight() {
       return this.height;// return width
   }

   // method to get area
   @Override
   public double area() { // return area of triangle
       return (this.base * this.height) / 2;
   }

   // method to string
   public String toString() {
       return "(" + getX() + ", " + getY() + ", " + getZ() + ")" + ":" + "/" +
               this.area() + "\\";
   }
}
