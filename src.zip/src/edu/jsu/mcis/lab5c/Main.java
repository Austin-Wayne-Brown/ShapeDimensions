package edu.jsu.mcis.lab5c;

public class Main {

    public static void main(String[] args) {
       //Create shapes
       Shape s1=new Circle(3,5,7,4.0);
       Shape s2=new Circle(6,8,9,2.5);
       Shape s3=new Rectangle(3,4,5,5.0,10.0);
       Shape s4=new Rectangle(8,9,10,4.0,9.0);
       Shape s5=new Triangle(4,5,6,8.0,6.0);
       Shape s6=new Triangle(5,8,10,10.0,4.0);
       
       //Store shapes into an ArrayList
       Shape shapes[]={s1,s2,s3,s4,s5,s6};
     
       // Print shapes as String
       System.out.println(s1.toString());
       System.out.println(s2.toString());
       System.out.println(s3.toString());
       System.out.println(s4.toString());
       System.out.println(s5.toString());
       System.out.println(s6.toString());

   }
}

